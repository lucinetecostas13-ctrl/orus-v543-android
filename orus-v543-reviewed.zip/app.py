import base64
import difflib
import hashlib
import hmac
import shutil
import zipfile
import io
import json
import os
import re
import secrets
import shlex
import time
import unicodedata
from urllib import error as urlerror
from urllib import request as urlrequest
from pathlib import Path
from typing import Any
import xml.etree.ElementTree as ET

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()

APP_VERSION = "54.3"
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6")
OPENAI_IMAGE_MODEL = os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-2")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
GEMINI_FALLBACK_MODELS = [m.strip() for m in os.getenv(
    "GEMINI_FALLBACK_MODELS",
    "gemini-3.8-flash,gemini-3.7-flash,gemini-3.6-flash,gemini-3.5-flash,gemini-3.5-flash-lite",
).split(",") if m.strip()]
GEMINI_TTS_MODEL = os.getenv("GEMINI_TTS_MODEL", "gemini-3.8-flash-tts")
GEMINI_TTS_VOICE = os.getenv("GEMINI_TTS_VOICE", "Orus")
GEMINI_LIVE_MODEL = os.getenv("GEMINI_LIVE_MODEL", "gemini-3.8-live")
GEMINI_IMAGE_MODEL = os.getenv("GEMINI_IMAGE_MODEL", "gemini-3.1-flash-image")
ORUS_NATIVE_IMAGE = os.getenv("ORUS_NATIVE_IMAGE", "0").strip().lower() in {"1", "true", "yes"}
ORUS_AI_PROVIDER = os.getenv("ORUS_AI_PROVIDER", "auto").strip().lower()
ORUS_ACCESS_TOKEN = os.getenv("ORUS_ACCESS_TOKEN", "").strip()
ORUS_ALLOW_UNAUTHENTICATED = os.getenv("ORUS_ALLOW_UNAUTHENTICATED", "0").strip().lower() in {"1", "true", "yes"}
ALLOWED_ORIGINS = [x.strip() for x in os.getenv("ORUS_ALLOWED_ORIGINS", "").split(",") if x.strip()]
UPLOAD_DIR = Path(os.getenv("ORUS_UPLOAD_DIR", "/tmp/orus_uploads"))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
HOME_ASSISTANT_URL = os.getenv("HOME_ASSISTANT_URL", "").strip().rstrip("/")
HOME_ASSISTANT_TOKEN = os.getenv("HOME_ASSISTANT_TOKEN", "").strip()
HOME_ASSISTANT_TIMEOUT = int(os.getenv("HOME_ASSISTANT_TIMEOUT", "8"))
EVOLUTION_DIR = Path(os.getenv("ORUS_EVOLUTION_DIR", "/tmp/orus_evolution"))
EVOLUTION_DIR.mkdir(parents=True, exist_ok=True)
(EVOLUTION_DIR / "candidates").mkdir(exist_ok=True)
(EVOLUTION_DIR / "checkpoints").mkdir(exist_ok=True)
(EVOLUTION_DIR / "approved").mkdir(exist_ok=True)
EVOLUTION_STATE_PATH = EVOLUTION_DIR / "state.json"
ORUS_CLIENT_SOURCE = (Path(__file__).with_name("static") / "index.html") if (Path(__file__).with_name("static") / "index.html").exists() else (Path(__file__).with_name("client") / "ORUS-V53.html")
EVOLUTION_ID_RE = re.compile(r"^[A-Za-z0-9_-]{6,80}$")

app = FastAPI(title="ORUS Core", version=APP_VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Lightweight in-memory state. Replace with Postgres/Redis for production persistence.
PROJECT_TEXT_INDEX: dict[str, list[dict[str, Any]]] = {}
SANDBOX_IDS: dict[str, str] = {}
PENDING_HOME_ACTIONS: dict[str, dict[str, Any]] = {}
RUNTIME_METRICS: dict[str, Any] = {"requests": 0, "errors": 0, "total_latency_ms": 0.0, "by_path": {}, "recent_errors": []}
SKILLS_PATH = Path(__file__).with_name('skills.json')
try:
    SKILLS: list[dict[str, Any]] = json.loads(SKILLS_PATH.read_text(encoding='utf-8'))
except Exception:
    SKILLS = []
SKILL_BY_ID = {s.get('id'): s for s in SKILLS if s.get('id')}


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=50000)
    mode: str = "omni"
    session_id: str | None = None
    project_id: str = "general"
    client_version: str | None = None
    skill_id: str | None = None
    history: list[dict[str, str]] = Field(default_factory=list)


class AgentRunRequest(BaseModel):
    agent: str = Field(min_length=1, max_length=80)
    mission: str = Field(min_length=1, max_length=50000)
    project_id: str = "general"
    session_id: str | None = None


class ImageRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=8000)
    project_id: str = "general"


class ExecuteRequest(BaseModel):
    command: str = Field(min_length=1, max_length=12000)
    project_id: str = "general"
    timeout: int = Field(default=120, ge=1, le=300)


class VoiceCommandRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    project_id: str = "general"
    session_id: str | None = None


class VoiceSpeakRequest(BaseModel):
    text: str = Field(min_length=1, max_length=6000)
    style: str | None = Field(default=None, max_length=600)


class HomeCommandRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)


class HomeConfirmRequest(BaseModel):
    confirmation_token: str = Field(min_length=8, max_length=4000)


class EvolutionAnalyzeRequest(BaseModel):
    goal: str = Field(default="Melhorar confiabilidade, segurança, desempenho e experiência sem remover funcionalidades existentes.", min_length=3, max_length=12000)


class EvolutionCreateRequest(BaseModel):
    goal: str = Field(min_length=3, max_length=12000)


class EvolutionApproveRequest(BaseModel):
    candidate_id: str = Field(min_length=6, max_length=80)
    confirm: bool = False


class EvolutionRollbackRequest(BaseModel):
    checkpoint_id: str = Field(min_length=6, max_length=80)
    confirm: bool = False


class EvolutionFeedbackRequest(BaseModel):
    text: str = Field(min_length=1, max_length=8000)
    kind: str = Field(default="feedback", max_length=40)


HOME_DOMAINS = {"light", "switch", "fan", "climate", "media_player", "cover", "lock", "alarm_control_panel", "vacuum", "scene", "script", "valve", "button", "input_boolean"}
HOME_SERVICE_ALLOWLIST = {
    "light": {"turn_on", "turn_off", "toggle"},
    "switch": {"turn_on", "turn_off", "toggle"},
    "fan": {"turn_on", "turn_off", "toggle", "set_percentage"},
    "climate": {"turn_on", "turn_off", "set_temperature", "set_hvac_mode"},
    "media_player": {"turn_on", "turn_off", "media_play", "media_pause", "media_play_pause", "volume_up", "volume_down", "volume_set"},
    "cover": {"open_cover", "close_cover", "stop_cover", "set_cover_position"},
    "lock": {"lock", "unlock"},
    "alarm_control_panel": {"alarm_arm_home", "alarm_arm_away", "alarm_disarm"},
    "vacuum": {"start", "stop", "pause", "return_to_base"},
    "scene": {"turn_on"},
    "script": {"turn_on"},
    "valve": {"open_valve", "close_valve", "stop_valve"},
    "button": {"press"},
    "input_boolean": {"turn_on", "turn_off", "toggle"},
}
RISKY_HOME_ACTIONS = {
    ("lock", "unlock"),
    ("cover", "open_cover"),
    ("alarm_control_panel", "alarm_disarm"),
    ("valve", "open_valve"),
    ("button", "press"),
    ("script", "turn_on"),
    ("scene", "turn_on"),
}
HOME_DATA_KEYS = {"temperature", "brightness_pct", "percentage", "volume_level", "hvac_mode", "position"}
PROJECT_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,96}$")


def safe_project_id(value: str | None) -> str:
    value = (value or "general").strip()
    if not PROJECT_ID_RE.fullmatch(value):
        raise HTTPException(status_code=400, detail="project_id inválido.")
    return value


def safe_upload_name(value: str | None) -> str:
    name = Path(value or "arquivo").name.strip()
    if not name or name in {".", ".."}:
        name = "arquivo"
    name = re.sub(r"[^A-Za-z0-9._ -]+", "_", name)[:180]
    return name or "arquivo"


def safe_sandbox_path(value: str) -> str:
    from pathlib import PurePosixPath
    root = PurePosixPath("/tmp/orus")
    path = PurePosixPath(value)
    if not path.is_absolute() or ".." in path.parts or not str(path).startswith(str(root) + "/"):
        raise HTTPException(status_code=400, detail="Somente arquivos dentro de /tmp/orus podem ser lidos.")
    return str(path)


def home_assistant_ready() -> bool:
    return bool(HOME_ASSISTANT_URL and HOME_ASSISTANT_TOKEN)


def ha_request(method: str, path: str, payload: dict[str, Any] | None = None) -> Any:
    if not home_assistant_ready():
        raise HTTPException(status_code=503, detail="Home Assistant ainda não está configurado no ORUS Core.")
    url = HOME_ASSISTANT_URL + path
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urlrequest.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {HOME_ASSISTANT_TOKEN}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
    )
    try:
        with urlrequest.urlopen(req, timeout=HOME_ASSISTANT_TIMEOUT) as resp:
            body = resp.read()
            return json.loads(body.decode("utf-8")) if body else None
    except urlerror.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:1000]
        raise HTTPException(status_code=502, detail=f"Home Assistant respondeu HTTP {exc.code}: {detail}") from exc
    except (urlerror.URLError, TimeoutError) as exc:
        raise HTTPException(status_code=502, detail=f"Não foi possível conectar ao Home Assistant: {exc}") from exc


def get_home_entities() -> list[dict[str, Any]]:
    states = ha_request("GET", "/api/states") or []
    entities: list[dict[str, Any]] = []
    for item in states:
        entity_id = str(item.get("entity_id", ""))
        domain = entity_id.split(".", 1)[0] if "." in entity_id else ""
        if domain not in HOME_DOMAINS:
            continue
        attrs = item.get("attributes") or {}
        entities.append(
            {
                "entity_id": entity_id,
                "domain": domain,
                "name": attrs.get("friendly_name") or entity_id,
                "state": item.get("state", "unknown"),
                "device_class": attrs.get("device_class"),
                "unit": attrs.get("unit_of_measurement"),
            }
        )
    entities.sort(key=lambda x: (x["domain"], str(x["name"]).lower()))
    return entities[:500]


def extract_json_object(text: str) -> dict[str, Any] | None:
    clean = text.strip().replace("```json", "").replace("```", "").strip()
    try:
        value = json.loads(clean)
        return value if isinstance(value, dict) else None
    except Exception:
        match = re.search(r"\{.*\}", clean, re.S)
        if not match:
            return None
        try:
            value = json.loads(match.group(0))
            return value if isinstance(value, dict) else None
        except Exception:
            return None


def resolve_home_action(text: str) -> dict[str, Any] | None:
    entities = get_home_entities()
    if not entities:
        return None
    inventory = "\n".join(f"- {e['entity_id']} | {e['name']} | estado={e['state']}" for e in entities[:180])
    instructions = (
        "Você é o roteador residencial da ORUS. Analise o comando em português e escolha no máximo UMA ação no Home Assistant. "
        "Use somente uma entity_id do inventário e somente serviços coerentes com o domínio. Se não for claramente residencial, "
        "retorne is_home_command=false. Responda APENAS JSON válido com: is_home_command, entity_id, domain, service, data, spoken."
    )
    prompt = f"COMANDO: {text}\n\nINVENTÁRIO:\n{inventory}"
    if gemini_ready():
        raw = call_gemini_text(prompt, instructions, thinking_level="low")
    elif openai_ready():
        client = get_openai_client()
        response = client.responses.create(model=OPENAI_MODEL, instructions=instructions, input=prompt)
        raw = getattr(response, "output_text", "") or ""
    else:
        raise HTTPException(status_code=503, detail="Nenhum provedor de IA está configurado para interpretar comandos residenciais.")
    parsed = extract_json_object(raw)
    if not parsed or not parsed.get("is_home_command"):
        return None
    entity_id = str(parsed.get("entity_id", ""))
    known = {e["entity_id"]: e for e in entities}
    if entity_id not in known:
        raise HTTPException(status_code=400, detail="Não encontrei com segurança o dispositivo solicitado.")
    domain = known[entity_id]["domain"]
    service = str(parsed.get("service", ""))
    if service not in HOME_SERVICE_ALLOWLIST.get(domain, set()):
        raise HTTPException(status_code=400, detail="A ação solicitada não está permitida para esse dispositivo.")
    raw_data = parsed.get("data") if isinstance(parsed.get("data"), dict) else {}
    data = {k: v for k, v in raw_data.items() if k in HOME_DATA_KEYS}
    data["entity_id"] = entity_id
    spoken = str(parsed.get("spoken") or f"Vou executar {service} em {known[entity_id]['name']}.")[:300]
    return {"entity_id":entity_id,"domain":domain,"service":service,"data":data,"name":known[entity_id]["name"],"spoken":spoken}


def execute_home_plan(plan: dict[str, Any]) -> Any:
    return ha_request("POST", f"/api/services/{plan['domain']}/{plan['service']}", plan["data"])


def _confirmation_key() -> bytes:
    value = ORUS_ACCESS_TOKEN or os.getenv("ORUS_CONFIRMATION_SECRET", "")
    if not value:
        raise HTTPException(status_code=503, detail="Um segredo do Core é necessário para confirmações sensíveis.")
    return hashlib.sha256(value.encode("utf-8")).digest()


def _make_home_confirmation(plan: dict[str, Any], ttl: int = 120) -> str:
    payload = {"exp": int(time.time()) + ttl, "plan": plan}
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    body = base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")
    sig = hmac.new(_confirmation_key(), body.encode("ascii"), hashlib.sha256).digest()
    return body + "." + base64.urlsafe_b64encode(sig).decode("ascii").rstrip("=")


def _read_home_confirmation(token: str) -> dict[str, Any]:
    try:
        body, sig_text = token.split(".", 1)
        pad = "=" * (-len(sig_text) % 4)
        supplied = base64.urlsafe_b64decode(sig_text + pad)
        expected = hmac.new(_confirmation_key(), body.encode("ascii"), hashlib.sha256).digest()
        if not secrets.compare_digest(supplied, expected):
            raise ValueError("signature")
        pad = "=" * (-len(body) % 4)
        payload = json.loads(base64.urlsafe_b64decode(body + pad).decode("utf-8"))
        if int(payload.get("exp", 0)) < int(time.time()):
            raise HTTPException(status_code=410, detail="A confirmação expirou. Diga o comando novamente.")
        plan = payload.get("plan")
        if not isinstance(plan, dict):
            raise ValueError("plan")
        domain, service = str(plan.get("domain", "")), str(plan.get("service", ""))
        if service not in HOME_SERVICE_ALLOWLIST.get(domain, set()):
            raise ValueError("allowlist")
        return plan
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=404, detail="Confirmação inválida ou já utilizada.") from exc


def handle_home_text(text: str) -> dict[str, Any] | None:
    plan = resolve_home_action(text)
    if not plan:
        return None
    risky = (plan["domain"], plan["service"]) in RISKY_HOME_ACTIONS
    if risky:
        token = _make_home_confirmation(plan)
        confirm_text = f"Confirme antes de executar: {plan['spoken']}"
        return {
            "kind": "home",
            "text": confirm_text,
            "confirmation_required": True,
            "confirmation_token": token,
            "confirmation_text": confirm_text,
            "plan": {"entity_id": plan["entity_id"], "domain": plan["domain"], "service": plan["service"], "name": plan["name"]},
        }
    execute_home_plan(plan)
    return {"kind": "home", "text": plan["spoken"], "confirmation_required": False, "plan": {"entity_id": plan["entity_id"], "domain": plan["domain"], "service": plan["service"], "name": plan["name"]}}


def _safe_evolution_id(value: str) -> str:
    value = (value or "").strip()
    if not EVOLUTION_ID_RE.fullmatch(value):
        raise HTTPException(status_code=400, detail="Identificador de evolução inválido.")
    return value


def _json_read(path: Path, fallback: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback


def _json_write(path: Path, value: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def evolution_state() -> dict[str, Any]:
    value = _json_read(EVOLUTION_STATE_PATH, {})
    if not isinstance(value, dict):
        value = {}
    value.setdefault("feedback", [])
    value.setdefault("approved_candidate", None)
    value.setdefault("rollback_target", None)
    return value


def save_evolution_state(value: dict[str, Any]) -> None:
    _json_write(EVOLUTION_STATE_PATH, value)


def self_source_files() -> dict[str, Path]:
    base = Path(__file__).resolve().parent
    rows = {
        "app.py": base / "app.py",
        "pyproject.toml": base / "pyproject.toml",
        "skills.json": base / "skills.json",
        "static/index.html": base / "static" / "index.html",
        "static/manifest.webmanifest": base / "static" / "manifest.webmanifest",
        "static/service-worker.js": base / "static" / "service-worker.js",
        "client/ORUS-V53.html": base / "client" / "ORUS-V53.html",
    }
    return {name: path for name, path in rows.items() if path.exists() and path.is_file()}


def source_manifest() -> list[dict[str, Any]]:
    out = []
    for name, path in self_source_files().items():
        data = path.read_bytes()
        out.append({"name": name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()[:16]})
    return out


def source_digest_for_ai() -> str:
    parts = [f"ORUS Core {APP_VERSION}", f"skills={len(SKILLS)}", f"metrics={json.dumps(RUNTIME_METRICS, ensure_ascii=False)[:6000]}"]
    for name, path in self_source_files().items():
        text = path.read_text(encoding="utf-8", errors="replace")
        if name.endswith(".html"):
            lines = [ln for ln in text.splitlines() if any(k in ln for k in ("const VERSION", "function ", "section id=", "data-view=", "fetchJSON", "evolution"))]
            sample = "\n".join(lines[:220])
        else:
            sample = text[:18000]
        parts.append(f"\n--- {name} ---\n{sample}")
    state = evolution_state()
    feedback = state.get("feedback", [])[-20:]
    if feedback:
        parts.append("\n--- FEEDBACK RECENTE ---\n" + json.dumps(feedback, ensure_ascii=False)[:10000])
    return "\n".join(parts)[:70000]


def make_evolution_id(prefix: str) -> str:
    return f"{prefix}_{int(time.time())}_{secrets.token_hex(3)}"


def candidate_dir(candidate_id: str) -> Path:
    return EVOLUTION_DIR / "candidates" / _safe_evolution_id(candidate_id)


def checkpoint_dir(checkpoint_id: str) -> Path:
    return EVOLUTION_DIR / "checkpoints" / _safe_evolution_id(checkpoint_id)


def snapshot_current(target: Path) -> None:
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True, exist_ok=True)
    for name, src in self_source_files().items():
        dst = target / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def candidate_meta(path: Path) -> dict[str, Any]:
    return _json_read(path / "candidate.json", {}) if path.exists() else {}


def write_candidate_meta(path: Path, meta: dict[str, Any]) -> None:
    _json_write(path / "candidate.json", meta)


def build_diff_summary(base_files: dict[str, Path], candidate_root: Path) -> dict[str, Any]:
    changed = []
    diff_chunks = []
    for name, base_path in base_files.items():
        cand = candidate_root / name
        if not cand.exists():
            changed.append({"file": name, "status": "removed"})
            continue
        a = base_path.read_text(encoding="utf-8", errors="replace").splitlines()
        b = cand.read_text(encoding="utf-8", errors="replace").splitlines()
        if a != b:
            changed.append({"file": name, "status": "modified", "before_lines": len(a), "after_lines": len(b)})
            if len(diff_chunks) < 4:
                diff = list(difflib.unified_diff(a, b, fromfile="base/"+name, tofile="candidate/"+name, n=2))
                diff_chunks.append("\n".join(diff[:220]))
    for cand in candidate_root.rglob("*"):
        if not cand.is_file() or cand.name == "candidate.json":
            continue
        rel = cand.relative_to(candidate_root).as_posix()
        if rel not in base_files:
            changed.append({"file": rel, "status": "added"})
    return {"changed_files": changed, "diff_preview": "\n\n".join(diff_chunks)[:30000]}


def validate_candidate_local(root: Path) -> list[dict[str, Any]]:
    tests: list[dict[str, Any]] = []
    app_file = root / "app.py"
    try:
        compile(app_file.read_text(encoding="utf-8"), "app.py", "exec")
        tests.append({"name": "python_syntax", "ok": True})
    except Exception as exc:
        tests.append({"name": "python_syntax", "ok": False, "detail": str(exc)[:500]})

    try:
        candidate_skills = json.loads((root / "skills.json").read_text(encoding="utf-8"))
        ok = isinstance(candidate_skills, list) and len(candidate_skills) >= 250 and len({x.get("id") for x in candidate_skills}) == len(candidate_skills)
        tests.append({"name": "skills_catalog", "ok": ok, "count": len(candidate_skills) if isinstance(candidate_skills, list) else 0})
    except Exception as exc:
        tests.append({"name": "skills_catalog", "ok": False, "detail": str(exc)[:500]})

    static_client = root / "static" / "index.html"
    mirror_client = root / "client" / "ORUS-V53.html"
    for label, client in (("static_client", static_client), ("mirror_client", mirror_client)):
        if client.exists():
            text = client.read_text(encoding="utf-8", errors="replace")
            required = ["evolutionView", "ORUS_ACCESS_TOKEN", "const VERSION='", 'data-view="evolution"', "fetchJSON"]
            tests.append({"name": label + "_invariants", "ok": all(x in text for x in required)})
        else:
            tests.append({"name": label + "_invariants", "ok": False, "detail": "arquivo ausente"})

    if static_client.exists() and mirror_client.exists():
        tests.append({"name": "client_mirror_sync", "ok": static_client.read_bytes() == mirror_client.read_bytes()})

    main_text = app_file.read_text(encoding="utf-8", errors="replace") if app_file.exists() else ""
    security_required = ["secrets.compare_digest", "ORUS_ACCESS_TOKEN", "safe_project_id", "confirmation_required", "/tmp/orus"]
    tests.append({"name": "security_invariants", "ok": all(x in main_text for x in security_required) and "/home/oai" not in main_text})
    api_required = ['@app.post("/v1/chat"', '@app.post("/v1/voice/command"', '@app.post("/v1/evolution/create"', '@app.get("/health"']
    tests.append({"name": "api_routes_preserved", "ok": all(x in main_text for x in api_required)})

    # Reject obvious embedded secrets in generated source.
    joined = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in root.rglob("*") if p.is_file() and p.suffix.lower() in {".py", ".html", ".js", ".json", ".toml", ".md"})
    suspicious = bool(re.search(r"(?:sk-proj-[A-Za-z0-9_-]{20,}|e2b_[A-Za-z0-9]{24,}|AIza[0-9A-Za-z_-]{30,})", joined))
    tests.append({"name": "no_embedded_secrets", "ok": not suspicious})
    return tests


def package_directory(root: Path, zip_path: Path) -> Path:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in root.rglob("*"):
            if p.is_file():
                zf.write(p, p.relative_to(root).as_posix())
    return zip_path


def require_access(authorization: str | None = Header(default=None)) -> None:
    if not ORUS_ACCESS_TOKEN:
        if ORUS_ALLOW_UNAUTHENTICATED:
            return
        raise HTTPException(status_code=503, detail="ORUS_ACCESS_TOKEN não configurado. Para desenvolvimento local, habilite explicitamente ORUS_ALLOW_UNAUTHENTICATED=1.")
    expected = f"Bearer {ORUS_ACCESS_TOKEN}"
    if not authorization or not secrets.compare_digest(authorization, expected):
        raise HTTPException(status_code=401, detail="Token de acesso ORUS inválido ou ausente.")


def openai_ready() -> bool:
    return bool(os.getenv("OPENAI_API_KEY", "").strip())


def gemini_ready() -> bool:
    return bool(os.getenv("GEMINI_API_KEY", "").strip())


def ai_ready() -> bool:
    return gemini_ready() or openai_ready()


def active_ai_provider() -> str | None:
    if ORUS_AI_PROVIDER == "gemini":
        return "gemini" if gemini_ready() else None
    if ORUS_AI_PROVIDER == "openai":
        return "openai" if openai_ready() else None
    # auto: prefere o nível gratuito do Gemini quando configurado.
    if gemini_ready():
        return "gemini"
    if openai_ready():
        return "openai"
    return None


def active_ai_model() -> str | None:
    provider = active_ai_provider()
    if provider == "gemini":
        return GEMINI_MODEL
    if provider == "openai":
        return OPENAI_MODEL
    return None


def e2b_ready() -> bool:
    return bool(os.getenv("E2B_API_KEY", "").strip())


def get_openai_client():
    if not openai_ready():
        raise HTTPException(status_code=503, detail="OPENAI_API_KEY não configurada no servidor.")
    from openai import OpenAI

    return OpenAI(api_key=os.environ["OPENAI_API_KEY"])


def gemini_model_ladder() -> list[str]:
    rows: list[str] = []
    for model in [GEMINI_MODEL, *GEMINI_FALLBACK_MODELS]:
        if model and model not in rows:
            rows.append(model)
    return rows


def _gemini_error_detail(raw: str) -> str:
    try:
        return str(json.loads(raw).get("error", {}).get("message") or raw)
    except Exception:
        return raw


def _gemini_transient(status: int, detail: str) -> bool:
    d = detail.lower()
    return status in {404, 408, 409, 429, 500, 502, 503, 504} or any(x in d for x in (
        "high demand", "overload", "temporar", "unavailable", "resource exhausted", "rate limit", "try again"
    ))


def _clean_chat_history(history: list[dict[str, str]] | None, max_turns: int = 14) -> list[dict[str, str]]:
    clean: list[dict[str, str]] = []
    for row in (history or [])[-max_turns:]:
        if not isinstance(row, dict):
            continue
        role = str(row.get("role") or "").lower().strip()
        text = str(row.get("content") or row.get("text") or "").strip()
        if not text:
            continue
        if role in {"assistant", "orus", "model"}:
            role = "model"
        elif role == "user":
            role = "user"
        else:
            continue
        clean.append({"role": role, "text": text[:16000]})
    return clean


def _extract_grounded_sources(data: dict[str, Any]) -> list[tuple[str, str]]:
    found: list[tuple[str, str]] = []
    seen: set[str] = set()

    def walk(node: Any):
        if isinstance(node, dict):
            url = node.get("uri") or node.get("url")
            if isinstance(url, str) and url.startswith(("http://", "https://")) and url not in seen:
                title = str(node.get("title") or node.get("displayName") or node.get("domain") or "Fonte")
                seen.add(url)
                found.append((title[:140], url))
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for value in node:
                walk(value)

    for candidate in data.get("candidates", []) or []:
        if isinstance(candidate, dict):
            for key in ("groundingMetadata", "grounding_metadata", "urlContextMetadata", "url_context_metadata"):
                if key in candidate:
                    walk(candidate[key])
    return found[:8]


def _omni_features(message: str, mode: str) -> dict[str, Any]:
    text = (message or "").lower()
    has_url = bool(re.search(r"https?://\\S+", message or "", flags=re.I))
    fresh = bool(re.search(r"\\b(hoje|agora|atual|atualmente|últim[oa]s?|notícias?|preço|cotação|resultado|2026|pesquise|pesquisar|internet|web)\\b", text))
    codeish = bool(re.search(r"\\b(código|codigo|python|javascript|typescript|sql|calcule|cálculo|analise dados|planilha|csv|estatística|estatistica)\\b", text))
    deepish = mode in {"deep", "research", "code"} or len(message or "") > 1800 or bool(re.search(r"\\b(aprofund|complex|arquitetura|estratégia|estrategia|compare|investigue|diagnostique)\\b", text))
    return {
        "search": mode == "research" or (mode == "omni" and fresh),
        "url": has_url and mode in {"omni", "research", "deep", "chat"},
        "code": mode == "code" or (mode == "omni" and codeish),
        "thinking": "high" if deepish else "medium",
    }


def call_gemini_text(
    message: str,
    instructions: str = "",
    enable_search: bool = False,
    enable_code: bool = False,
    enable_url: bool = False,
    thinking_level: str = "medium",
    history: list[dict[str, str]] | None = None,
) -> str:
    if not gemini_ready():
        raise HTTPException(status_code=503, detail="GEMINI_API_KEY não configurada no servidor.")

    last_detail = "Falha desconhecida"
    clean_history = _clean_chat_history(history)
    for model_index, model in enumerate(gemini_model_ladder()):
        for attempt in range(2):
            endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
            contents: list[dict[str, Any]] = []
            for turn in clean_history:
                contents.append({"role": turn["role"], "parts": [{"text": turn["text"]}]})
            contents.append({"role": "user", "parts": [{"text": message}]})
            generation_config: dict[str, Any] = {"maxOutputTokens": 16384}
            if model.startswith("gemini-3") and thinking_level in {"low", "medium", "high"}:
                generation_config["thinkingConfig"] = {"thinkingLevel": thinking_level}
            payload: dict[str, Any] = {
                "contents": contents,
                "generationConfig": generation_config,
            }
            if instructions:
                payload["system_instruction"] = {"parts": [{"text": instructions}]}
            tools: list[dict[str, Any]] = []
            if enable_search:
                tools.append({"google_search": {}})
            if enable_url:
                tools.append({"url_context": {}})
            if enable_code:
                tools.append({"code_execution": {}})
            if tools:
                payload["tools"] = tools
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            req = urlrequest.Request(endpoint, data=body, headers={
                "Content-Type": "application/json",
                "x-goog-api-key": os.environ["GEMINI_API_KEY"],
            }, method="POST")
            try:
                with urlrequest.urlopen(req, timeout=110) as response:
                    data = json.loads(response.read().decode("utf-8"))
                parts: list[str] = []
                for candidate in data.get("candidates", []) or []:
                    content = candidate.get("content") or {}
                    for part in content.get("parts", []) or []:
                        if not isinstance(part, dict):
                            continue
                        text = part.get("text")
                        if text:
                            parts.append(str(text))
                        code_result = part.get("codeExecutionResult") or part.get("code_execution_result")
                        if isinstance(code_result, dict) and code_result.get("output"):
                            parts.append(f"Resultado da execução:\n{code_result.get('output')}")
                text = "\n".join(parts).strip()
                sources = _extract_grounded_sources(data)
                if text and sources:
                    text += "\n\nFontes consultadas:\n" + "\n".join(f"- {title}: {url}" for title, url in sources)
                if text:
                    return text
                last_detail = f"{model} respondeu sem texto utilizável"
            except urlerror.HTTPError as exc:
                raw = exc.read().decode("utf-8", errors="replace")
                detail = _gemini_error_detail(raw)
                last_detail = f"{model}: {detail[:900]}"
                # Alguns níveis/chaves não aceitam todas as ferramentas. Degrada de forma segura.
                if (enable_search or enable_url or enable_code) and exc.code in {400, 403}:
                    try:
                        return call_gemini_text(
                            message, instructions, enable_search=False, enable_code=False, enable_url=False,
                            thinking_level=thinking_level, history=history,
                        )
                    except HTTPException as fallback_exc:
                        last_detail = str(fallback_exc.detail)
                elif exc.code in {400, 403} and thinking_level in {"low", "medium", "high"} and "thinking" in detail.lower():
                    try:
                        return call_gemini_text(
                            message, instructions, enable_search=False, enable_code=False, enable_url=False,
                            thinking_level="off", history=history,
                        )
                    except HTTPException as fallback_exc:
                        last_detail = str(fallback_exc.detail)
                if not _gemini_transient(exc.code, detail):
                    raise HTTPException(status_code=502, detail=f"Gemini API: {detail[:1200]}") from exc
            except Exception as exc:
                last_detail = f"{model}: {exc}"
            if attempt == 0:
                time.sleep(0.55 + model_index * 0.15)
    raise HTTPException(status_code=503, detail=f"Gemini temporariamente indisponível após fallback automático. Último erro: {last_detail[:900]}")


def project_context(project_id: str) -> str:
    project_id = safe_project_id(project_id)
    docs = PROJECT_TEXT_INDEX.get(project_id, [])
    if not docs:
        return ""
    chunks = []
    total = 0
    for doc in docs[-12:]:
        text = doc.get("text", "")
        if not text:
            continue
        piece = f"\n--- ARQUIVO: {doc.get('name','arquivo')} ---\n{text[:12000]}"
        if total + len(piece) > 42000:
            break
        chunks.append(piece)
        total += len(piece)
    return "\n".join(chunks)


def normalize_text(value: str) -> str:
    value = unicodedata.normalize("NFD", value.lower())
    value = "".join(c for c in value if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9]+", " ", value).strip()


def stem_token(token: str) -> str:
    token = normalize_text(token)
    for ending in ("ando", "endo", "indo", "ariam", "eriam", "iriam", "aria", "eria", "iria", "ou", "ei", "ar", "er", "ir", "es", "e", "a", "o"):
        if len(token) >= 5 and token.endswith(ending) and len(token) - len(ending) >= 3:
            return token[:-len(ending)]
    return token


def route_skill(message: str, requested_id: str | None = None) -> dict[str, Any] | None:
    if requested_id and requested_id in SKILL_BY_ID:
        return SKILL_BY_ID[requested_id]
    text = normalize_text(message)
    if not text:
        return None
    words = set(text.split())
    stems = {stem_token(w) for w in words}
    if words & {"pesquise", "buscar", "busque", "procure", "pesquisar"}:
        direct = SKILL_BY_ID.get("pesquisa-e-conhecimento--pesquisar-na-web")
        if direct:
            return direct
    if re.search(r"\b(crie|criar|gere|gerar|faca|fazer|desenhe|desenhar|produza|produzir)\b.*\b(imagem|foto|arte|banner|thumbnail|logo|ilustracao)\b", text):
        direct = SKILL_BY_ID.get("midia-e-design--gerar-imagem")
        if direct:
            return direct
    best = None
    best_score = 0
    generic = {"criar", "fazer", "gerar", "usar", "analisar", "montar", "revisar"}
    for skill in SKILLS:
        score = 0
        name = normalize_text(str(skill.get("name", "")))
        if name and name in text:
            score += 14
        name_stems = {stem_token(w) for w in name.split()}
        score += min(6, len(stems & name_stems) * 2)
        for kw in skill.get("keywords") or []:
            nkw = normalize_text(str(kw))
            if not nkw:
                continue
            if nkw in text:
                score += 5 if nkw not in generic else 1
            elif stem_token(nkw) in stems:
                score += 3 if nkw not in generic else 1
        cat = normalize_text(str(skill.get("category", "")))
        if cat and any(w in words for w in cat.split() if len(w) > 4):
            score += 1
        # Context bonuses reduce false routing caused by generic verbs such as "criar" or "fazer".
        if any(w in words for w in {"arquivo", "arquivos", "documento", "documentos", "pdf"}) and cat == "arquivos e documentos":
            score += 7
        if any(st.startswith("pesquis") for st in stems) and cat == "pesquisa e conhecimento":
            score += 7
        if any(w in words for w in {"app", "aplicativo", "site", "website"}) and cat == "apps e web":
            score += 6
        if any(w in words for w in {"imagem", "foto", "banner", "thumbnail", "arte", "logo"}) and cat == "midia e design":
            score += 8
        if "app" in words and "aplicativo" in name:
            score += 5
        if score > best_score:
            best, best_score = skill, score
    return best if best_score >= 4 else None


def skill_instruction(skill: dict[str, Any] | None) -> str:
    if not skill:
        return ""
    return (
        f" Habilidade ORUS selecionada: {skill.get('name')} ({skill.get('category')}). "
        f"Objetivo: {skill.get('description')} "
        "Use essa habilidade como especialização para responder ao pedido atual, sem afirmar que integrações ausentes foram executadas."
    )


def build_instructions(mode: str, project_id: str, skill: dict[str, Any] | None = None) -> str:
    provider = active_ai_provider() or "nenhum"
    capabilities = [
        "chat e raciocínio com o provedor de IA configurado",
        "projetos e histórico local na interface ORUS",
        "arquivos enviados ao projeto",
        "execução de código no E2B" if e2b_ready() else "execução E2B ainda não configurada",
        "autoaprimoramento em sandbox com candidata, testes, checkpoint e rollback",
        "voz pelo navegador quando houver permissão",
        "Home Assistant quando configurado",
        "geração de imagem vetorial gratuita por IA; geração raster depende de provedor compatível",
    ]
    base = (
        "Você é ORUS, o assistente do aplicativo ORUS. Não se apresente como ChatGPT, Gemini, OpenAI ou outro produto. "
        "Se perguntarem qual motor de IA está sendo usado, responda com transparência que o ORUS usa o provedor configurado no servidor, "
        f"que neste momento é {provider}. "
        "Você está rodando dentro da interface web/mobile do ORUS, não dentro do aplicativo ChatGPT. "
        "Nunca diga genericamente que é apenas uma IA de texto quando o ORUS possui uma ferramenta específica para a tarefa. "
        "Sobre o celular: não diga que é impossível interagir com o aparelho em termos absolutos; explique que o ORUS só acessa recursos "
        "que o navegador, o sistema e as integrações conectadas realmente autorizarem. "
        "Não invente acesso a contatos, chamadas, câmera, arquivos locais, apps ou configurações sem integração/permissão real. "
        "Capacidades atuais do ORUS: " + "; ".join(capabilities) + ". "
        "Seja claro, útil e preciso. Não afirme ter executado ações que não foram realmente executadas. "
        "Quando houver riscos, segredos ou ações externas, preserve credenciais e peça aprovação quando necessário. "
        "Em tarefas de software, produza passos verificáveis e código quando útil. "
        "Responda em português do Brasil, salvo se o usuário pedir outro idioma."
    )
    if mode == "code":
        base += " Foque em engenharia de software, correção, testes e explicações técnicas objetivas."
    elif mode == "files":
        base += " Use prioritariamente o conteúdo dos arquivos enviados para o projeto."
    elif mode == "research":
        base += " Pesquise na web quando a ferramenta estiver disponível e diferencie fatos verificados de inferências."
    if project_id:
        base += f" Projeto atual: {project_id}."
    base += skill_instruction(skill)
    return base


def call_openai_text(
    message: str,
    mode: str,
    project_id: str,
    skill: dict[str, Any] | None = None,
    history: list[dict[str, str]] | None = None,
) -> str:
    """Roteador multimodal/agentic: usa Gemini gratuito primeiro e OpenAI quando configurada."""
    context = project_context(project_id) if mode == "files" else ""
    user_input = message if not context else f"{message}\n\nContexto de arquivos do projeto:{context}"
    instructions = build_instructions(mode, project_id, skill)
    provider = active_ai_provider()
    if not provider:
        raise HTTPException(status_code=503, detail="Nenhuma IA configurada. Defina GEMINI_API_KEY ou OPENAI_API_KEY.")

    features = _omni_features(user_input, mode)
    if mode == "omni":
        instructions += (
            " Você está no modo ORUS Omni. Decida quando pesquisar a web, raciocinar profundamente, "
            "usar execução de código ou interpretar URLs. Seja transparente sobre o que realmente executou."
        )

    if provider == "gemini":
        return call_gemini_text(
            user_input,
            instructions,
            enable_search=features["search"],
            enable_code=features["code"],
            enable_url=features["url"],
            thinking_level=features["thinking"],
            history=history,
        )

    client = get_openai_client()
    clean_history = _clean_chat_history(history)
    input_items: list[dict[str, Any]] = []
    for turn in clean_history:
        input_items.append({"role": "assistant" if turn["role"] == "model" else "user", "content": turn["text"]})
    input_items.append({"role": "user", "content": user_input})
    kwargs: dict[str, Any] = {
        "model": active_ai_model(),
        "instructions": instructions,
        "input": input_items,
        "reasoning": {"effort": "high" if features["thinking"] == "high" else "medium"},
    }
    tools: list[dict[str, Any]] = []
    if features["search"] or features["url"]:
        tools.append({"type": "web_search"})
    if tools:
        kwargs["tools"] = tools
    try:
        response = client.responses.create(**kwargs)
    except Exception:
        if gemini_ready():
            return call_gemini_text(
                user_input,
                instructions,
                enable_search=features["search"],
                enable_code=features["code"],
                enable_url=features["url"],
                thinking_level=features["thinking"],
                history=history,
            )
        raise
    text = getattr(response, "output_text", None)
    if not text:
        raise HTTPException(status_code=502, detail="A API de IA respondeu sem texto utilizável.")
    return text


def connect_or_create_sandbox(project_id: str):
    project_id = safe_project_id(project_id)
    if not e2b_ready():
        raise HTTPException(status_code=503, detail="E2B_API_KEY não configurada no servidor.")
    if not ai_ready():
        raise HTTPException(status_code=503, detail="Configure GEMINI_API_KEY ou OPENAI_API_KEY para usar o executor inteligente.")

    from e2b import Sandbox

    current_id = SANDBOX_IDS.get(project_id)
    if current_id:
        try:
            sbx = Sandbox.connect(current_id, timeout=900)
            if sbx.is_running():
                sbx.set_timeout(900)
                return sbx
        except Exception:
            SANDBOX_IDS.pop(project_id, None)

    try:
        # Por padrão, nenhuma chave de IA é copiada para o sandbox. Isso evita que
        # código gerado dentro do E2B consiga ler/exfiltrar credenciais do provedor.
        envs = {}
        legacy_cli = os.getenv("ORUS_E2B_AI_CLI", "0").strip().lower() in {"1", "true", "yes"}
        if legacy_cli:
            if gemini_ready():
                envs["GEMINI_API_KEY"] = os.environ["GEMINI_API_KEY"]
                envs["GEMINI_MODEL"] = GEMINI_MODEL
            if openai_ready():
                envs["OPENAI_API_KEY"] = os.environ["OPENAI_API_KEY"]
        sbx = Sandbox.create(
            "openai-codex",
            timeout=900,
            metadata={"orus_project": project_id, "orus_version": APP_VERSION},
            envs=envs,
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Falha ao criar sandbox E2B: {exc}") from exc

    try:
        sbx.commands.run("mkdir -p /tmp/orus && chmod 700 /tmp/orus", timeout=20, request_timeout=25)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Falha ao preparar diretório gravável do E2B: {exc}") from exc

    SANDBOX_IDS[project_id] = sbx.sandbox_id
    return sbx


def _extract_shell_script(text: str) -> str:
    raw = (text or "").strip()
    match = re.search(r"```(?:bash|sh)?\s*([\s\S]*?)```", raw, flags=re.I)
    script = (match.group(1) if match else raw).strip()
    if not script:
        raise HTTPException(status_code=502, detail="A IA não retornou um plano executável para o E2B.")
    if len(script) > 50000:
        raise HTTPException(status_code=502, detail="O plano de execução gerado ficou grande demais.")
    forbidden = ("ORUS_ACCESS_TOKEN", "HOME_ASSISTANT_TOKEN", "GEMINI_API_KEY", "OPENAI_API_KEY", "E2B_API_KEY")
    if any(secret_name in script for secret_name in forbidden):
        raise HTTPException(status_code=502, detail="O plano gerado tentou referenciar um segredo e foi bloqueado.")
    return script


def _server_generated_build_script(mission: str) -> str:
    instructions = (
        "Você é o engenheiro executor da ORUS. Converta a missão em um script bash idempotente para executar DENTRO de /tmp/orus. "
        "O script pode criar/editar arquivos, instalar dependências comuns e rodar testes. Não leia variáveis de ambiente de segredo, "
        "não acesse /proc, /etc ou credenciais, e não tente sair de /tmp/orus. Responda SOMENTE com o script bash em bloco ```bash```."
    )
    text = call_gemini_text(mission, instructions, thinking_level="high") if gemini_ready() else call_openai_text(mission, "code", "general")
    return _extract_shell_script(text)


def run_codex_build(mission: str, project_id: str) -> dict[str, Any]:
    sbx = connect_or_create_sandbox(project_id)
    workdir = "/tmp/orus"
    legacy_cli = os.getenv("ORUS_E2B_AI_CLI", "0").strip().lower() in {"1", "true", "yes"}
    safe_prompt = (
        "Você está trabalhando dentro de um sandbox isolado da ORUS. Execute a tarefa no diretório /tmp/orus, "
        "crie ou altere arquivos, rode testes e resuma o resultado. Não revele segredos nem tente sair do sandbox.\n\nMISSÃO:\n" + mission
    )
    if legacy_cli:
        if gemini_ready():
            cmd = "npx -y @google/gemini-cli --approval-mode yolo --skip-trust -m " + shlex.quote(GEMINI_MODEL) + " -p " + shlex.quote(safe_prompt)
        else:
            cmd = "codex exec --skip-git-repo-check --dangerously-bypass-approvals-and-sandbox " + shlex.quote(safe_prompt)
    else:
        script = _server_generated_build_script(mission)
        encoded = base64.b64encode(script.encode("utf-8")).decode("ascii")
        cmd = "python - <<'PY'\nimport base64, pathlib\np=pathlib.Path('/tmp/orus/.orus_task.sh')\np.write_bytes(base64.b64decode('" + encoded + "'))\nPY\nbash /tmp/orus/.orus_task.sh"
    try:
        result = sbx.commands.run(cmd, cwd=workdir, timeout=360, request_timeout=370)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Falha durante execução no E2B: {exc}") from exc
    try:
        entries = sbx.files.list(workdir, depth=2)
        files = [{"name": getattr(e,"name",None), "path": getattr(e,"path",None), "type": str(getattr(e,"type",""))} for e in entries[:100]]
    except Exception:
        files=[]
    return {"sandbox_id": sbx.sandbox_id, "stdout": getattr(result,"stdout","") or "", "stderr": getattr(result,"stderr","") or "", "files": files}


def _sanitize_generated_svg(svg: str) -> str:
    svg = re.sub(r"<script\b.*?</script>", "", svg, flags=re.I | re.S)
    svg = re.sub(r"<foreignObject\b.*?</foreignObject>", "", svg, flags=re.I | re.S)
    svg = re.sub(r"\s+on[a-zA-Z]+\s*=\s*(\"[^\"]*\"|'[^']*'|[^\s>]+)", "", svg, flags=re.I)
    svg = re.sub(r"\s+(?:href|xlink:href)\s*=\s*([\"'])(?:javascript:|https?:|data:)[^\"']*\1", "", svg, flags=re.I)
    if "<svg" not in svg.lower() or "</svg>" not in svg.lower():
        raise HTTPException(status_code=502, detail="A IA não retornou um SVG válido.")
    return svg.strip()


def generate_gemini_svg_payload(prompt: str) -> dict[str, Any]:
    if not gemini_ready():
        raise HTTPException(status_code=503, detail="GEMINI_API_KEY não configurada para o modo de imagem vetorial.")

    instructions = (
        "Você é o gerador visual vetorial do ORUS. Gere UMA ilustração SVG completa, bonita e coerente com o pedido. "
        "Retorne somente <svg>...</svg>, sem markdown e sem explicações. "
        "Use viewBox='0 0 1024 1024'. Não use scripts, foreignObject, links externos, imagens remotas, javascript, animações ou fontes externas. "
        "Mantenha o SVG eficiente: no máximo cerca de 120 elementos vetoriais. "
        "Use formas, gradientes e texto curto somente quando realmente necessário. "
        "Se o pedido envolver pessoas, faça uma ilustração artística genérica, sem identificar pessoas reais."
    )

    endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"
    payload = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "system_instruction": {"parts": [{"text": instructions}]},
        "generationConfig": {
            "maxOutputTokens": 4096,
            "temperature": 0.7,
        },
    }
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urlrequest.Request(
        endpoint,
        data=body,
        headers={
            "Content-Type": "application/json",
            "x-goog-api-key": os.environ["GEMINI_API_KEY"],
        },
        method="POST",
    )
    try:
        with urlrequest.urlopen(req, timeout=80) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urlerror.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise HTTPException(status_code=502, detail=f"Gemini recusou a geração de imagem: {detail[:900]}") from exc
    except Exception as exc:
        raise HTTPException(status_code=504, detail=f"Tempo excedido na geração de imagem do Gemini: {exc}") from exc

    parts = (((data.get("candidates") or [{}])[0].get("content") or {}).get("parts") or [])
    raw = "\n".join(str(p.get("text") or "") for p in parts if isinstance(p, dict))
    match = re.search(r"<svg\b[\s\S]*?</svg>", raw, flags=re.I)
    if not match:
        raise HTTPException(status_code=502, detail="A IA não retornou uma ilustração SVG utilizável.")

    svg = _sanitize_generated_svg(match.group(0))
    return {
        "b64_json": base64.b64encode(svg.encode("utf-8")).decode("ascii"),
        "mime_type": "image/svg+xml",
        "engine": "gemini-svg",
        "text": "Ilustração vetorial gerada pelo ORUS.",
    }


def generate_gemini_native_image_payload(prompt: str) -> dict[str, Any]:
    if not gemini_ready():
        raise HTTPException(status_code=503, detail="GEMINI_API_KEY não configurada para imagem nativa.")
    endpoint = "https://generativelanguage.googleapis.com/v1beta/interactions"
    payload = {
        "model": GEMINI_IMAGE_MODEL,
        "input": [{"type": "text", "text": prompt}],
        "generation_config": {"thinking_level": "high"},
    }
    req = urlrequest.Request(endpoint, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"), headers={
        "Content-Type": "application/json", "x-goog-api-key": os.environ["GEMINI_API_KEY"]
    }, method="POST")
    try:
        with urlrequest.urlopen(req, timeout=110) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urlerror.HTTPError as exc:
        detail = _gemini_error_detail(exc.read().decode("utf-8", errors="replace"))
        raise HTTPException(status_code=502, detail=f"Gemini Image: {detail[:900]}") from exc
    interaction = data.get("interaction") or {}
    image = interaction.get("output_image") or interaction.get("outputImage") or {}
    b64 = image.get("data") if isinstance(image, dict) else None
    if not b64:
        raise HTTPException(status_code=502, detail="Gemini Image não retornou imagem utilizável.")
    mime = image.get("mime_type") or image.get("mimeType") or "image/png"
    return {"b64_json": b64, "mime_type": mime, "engine": GEMINI_IMAGE_MODEL, "text": "Imagem nativa gerada pelo ORUS."}


def generate_image_payload(prompt: str) -> dict[str, Any]:
    image_provider = os.getenv("ORUS_IMAGE_PROVIDER", "auto").strip().lower()

    # Imagem nativa moderna é opcional porque o nível gratuito da Gemini API pode não incluí-la.
    if gemini_ready() and (ORUS_NATIVE_IMAGE or image_provider in {"native", "gemini-native"}):
        try:
            return generate_gemini_native_image_payload(prompt)
        except HTTPException:
            if image_provider in {"native", "gemini-native"}:
                raise
    # Fallback gratuito: ilustração vetorial SVG segura.
    if gemini_ready() and image_provider in {"auto", "gemini", "svg", "native", "gemini-native"}:
        return generate_gemini_svg_payload(prompt)

    if openai_ready() and image_provider in {"auto", "openai", "raster"}:
        try:
            client = get_openai_client()
            result = client.images.generate(model=OPENAI_IMAGE_MODEL, prompt=prompt, size="1024x1024")
            item = result.data[0]
            b64 = getattr(item, "b64_json", None)
            url = getattr(item, "url", None)
            if b64:
                return {"b64_json": b64, "mime_type": "image/png", "engine": "openai-image", "text": "Imagem gerada."}
            if url:
                return {"url": url, "engine": "openai-image", "text": "Imagem gerada."}
        except Exception:
            if gemini_ready():
                return generate_gemini_svg_payload(prompt)
            raise

    if gemini_ready():
        return generate_gemini_svg_payload(prompt)

    raise HTTPException(
        status_code=503,
        detail="Nenhum gerador de imagem está disponível. Configure GEMINI_API_KEY ou um provedor raster compatível."
    )


def _xml_text(blob: bytes) -> str:
    try:
        root = ET.fromstring(blob)
        return " ".join((node.text or "").strip() for node in root.iter() if (node.text or "").strip())
    except Exception:
        return ""


def extract_upload_text(filename: str, data: bytes) -> str:
    suffix = Path(filename).suffix.lower()
    if suffix in {".txt", ".md", ".csv", ".json", ".html", ".css", ".js", ".ts", ".py", ".xml", ".yaml", ".yml", ".log", ".ini", ".sql", ".java", ".kt", ".gradle"}:
        return data.decode("utf-8", errors="replace")[:350000]
    if suffix == ".pdf":
        try:
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(data))
            text = "\n".join((page.extract_text() or "") for page in reader.pages[:160])
            return text[:350000]
        except Exception:
            return ""
    if suffix in {".docx", ".pptx", ".xlsx"}:
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                names = z.namelist()
                selected: list[str] = []
                if suffix == ".docx":
                    selected = [n for n in names if n.startswith("word/") and n.endswith(".xml")]
                elif suffix == ".pptx":
                    selected = [n for n in names if n.startswith("ppt/slides/slide") and n.endswith(".xml")]
                else:
                    selected = [n for n in names if (n.startswith("xl/worksheets/") or n == "xl/sharedStrings.xml") and n.endswith(".xml")]
                text = "\n".join(_xml_text(z.read(n)) for n in selected[:220])
                return text[:350000]
        except Exception:
            return ""
    if suffix == ".rtf":
        raw = data.decode("utf-8", errors="replace")
        raw = re.sub(r"\\'[0-9a-fA-F]{2}", " ", raw)
        raw = re.sub(r"\\[a-zA-Z]+-?\\d* ?", " ", raw)
        raw = raw.replace("{", " ").replace("}", " ")
        return re.sub(r"\\s+", " ", raw)[:350000]
    return ""


def describe_uploaded_image(filename: str, data: bytes, mime_type: str | None = None) -> str:
    if not gemini_ready() or len(data) > 8 * 1024 * 1024:
        return ""
    mime = mime_type or {".png":"image/png", ".jpg":"image/jpeg", ".jpeg":"image/jpeg", ".webp":"image/webp"}.get(Path(filename).suffix.lower(), "image/jpeg")
    endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"
    payload = {
        "contents": [{"role":"user","parts":[
            {"inline_data":{"mime_type":mime,"data":base64.b64encode(data).decode("ascii")}},
            {"text":"Analise esta imagem para uso posterior no projeto ORUS. Descreva conteúdo, textos legíveis, objetos, layout, cores e detalhes úteis. Não identifique pessoas reais pelo nome."}
        ]}],
        "generationConfig":{"maxOutputTokens":3000,"thinkingConfig":{"thinkingLevel":"low"}},
    }
    req = urlrequest.Request(endpoint, data=json.dumps(payload).encode("utf-8"), headers={"Content-Type":"application/json","x-goog-api-key":os.environ["GEMINI_API_KEY"]}, method="POST")
    try:
        with urlrequest.urlopen(req, timeout=70) as response:
            result=json.loads(response.read().decode("utf-8"))
        texts=[]
        for cand in result.get("candidates",[]) or []:
            for part in ((cand.get("content") or {}).get("parts") or []):
                if isinstance(part,dict) and part.get("text"):
                    texts.append(str(part["text"]))
        return "\n".join(texts).strip()[:30000]
    except Exception:
        return ""


@app.middleware("http")
async def collect_runtime_metrics(request, call_next):
    started = time.perf_counter()
    path = request.url.path
    RUNTIME_METRICS["requests"] += 1
    try:
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        response.headers.setdefault("Permissions-Policy", "camera=(self), microphone=(self), geolocation=()")
        response.headers.setdefault("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' data: blob:; connect-src 'self' https://generativelanguage.googleapis.com wss://generativelanguage.googleapis.com; frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'self'")
        if response.status_code >= 500:
            RUNTIME_METRICS["errors"] += 1
            RUNTIME_METRICS["recent_errors"].append({"path": path, "status": response.status_code, "time": int(time.time())})
        return response
    except Exception as exc:
        RUNTIME_METRICS["errors"] += 1
        RUNTIME_METRICS["recent_errors"].append({"path": path, "error": type(exc).__name__, "time": int(time.time())})
        raise
    finally:
        elapsed = (time.perf_counter() - started) * 1000
        RUNTIME_METRICS["total_latency_ms"] += elapsed
        row = RUNTIME_METRICS["by_path"].setdefault(path, {"count": 0, "errors": 0, "latency_ms": 0.0})
        row["count"] += 1
        row["latency_ms"] += elapsed
        RUNTIME_METRICS["recent_errors"] = RUNTIME_METRICS["recent_errors"][-30:]


@app.get("/health")
def health():
    return {
        "ok": True,
        "service": "ORUS Core",
        "version": APP_VERSION,
        "ai_configured": ai_ready(),
        "ai_provider": active_ai_provider(),
        "gemini_configured": gemini_ready(),
        "openai_configured": openai_ready(),
        "executor_configured": e2b_ready(),
        "home_assistant_configured": home_assistant_ready(),
        "access_token_required": not ORUS_ALLOW_UNAUTHENTICATED,
        "access_token_configured": bool(ORUS_ACCESS_TOKEN),
        "model": active_ai_model(),
        "model_fallbacks": gemini_model_ladder() if gemini_ready() else [],
        "natural_voice_available": gemini_ready(),
        "tts_model": GEMINI_TTS_MODEL if gemini_ready() else None,
        "tts_voice": GEMINI_TTS_VOICE if gemini_ready() else None,
        "live_voice_available": gemini_ready(),
        "live_model": GEMINI_LIVE_MODEL if gemini_ready() else None,
        "omni_mode": True,
        "deep_reasoning": True,
        "web_grounding": gemini_ready() or openai_ready(),
        "url_context": gemini_ready(),
        "code_execution": gemini_ready() or e2b_ready(),
        "conversation_memory": "browser+request-history",
        "vision_uploads": gemini_ready(),
        "native_image_model": GEMINI_IMAGE_MODEL if gemini_ready() else None,
        "image_generation_available": bool(gemini_ready() or openai_ready()),
        "image_generation_mode": "raster+svg" if openai_ready() and gemini_ready() else ("svg" if gemini_ready() else ("raster" if openai_ready() else None)),
        "active_sandboxes": len(SANDBOX_IDS),
        "skills_count": len(SKILLS),
        "evolution_enabled": True,
        "evolution_candidates": len(list((EVOLUTION_DIR / "candidates").glob("*/candidate.json"))),
        "core_integrity": all(callable(globals().get(n)) for n in ("route_skill","build_instructions","connect_or_create_sandbox","run_codex_build","generate_gemini_svg_payload")),
        "serverless_persistence": "ephemeral" if str(EVOLUTION_DIR).startswith("/tmp/") else "persistent_path",
        "time": int(time.time()),
    }



@app.get("/v1/skills", dependencies=[Depends(require_access)])
def list_skills(category: str | None = None, mode: str | None = None, q: str | None = None):
    rows = SKILLS
    if category:
        rows = [s for s in rows if s.get("category") == category]
    if mode:
        rows = [s for s in rows if s.get("mode") == mode]
    if q:
        nq = normalize_text(q)
        rows = [s for s in rows if nq in normalize_text(str(s.get("name", "")) + " " + str(s.get("description", "")) + " " + " ".join(s.get("keywords") or []))]
    return {"count": len(rows), "total": len(SKILLS), "skills": rows}

@app.get("/v1/skills/{skill_id}", dependencies=[Depends(require_access)])
def get_skill(skill_id: str):
    skill = SKILL_BY_ID.get(skill_id)
    if not skill:
        raise HTTPException(status_code=404, detail="Habilidade não encontrada.")
    return skill

@app.get("/v1/home/status", dependencies=[Depends(require_access)])
def home_status():
    if not home_assistant_ready():
        return {"configured": False, "reachable": False}
    try:
        info = ha_request("GET", "/api/")
        return {"configured": True, "reachable": True, "message": (info or {}).get("message") if isinstance(info, dict) else None}
    except HTTPException as exc:
        return {"configured": True, "reachable": False, "error": exc.detail}


@app.get("/v1/home/entities", dependencies=[Depends(require_access)])
def home_entities():
    return {"entities": get_home_entities()}


@app.post("/v1/home/command", dependencies=[Depends(require_access)])
def home_command(req: HomeCommandRequest):
    result = handle_home_text(req.text)
    if not result:
        raise HTTPException(status_code=400, detail="Não identifiquei um comando residencial claro.")
    return result


@app.post("/v1/home/confirm", dependencies=[Depends(require_access)])
def home_confirm(req: HomeConfirmRequest):
    plan = _read_home_confirmation(req.confirmation_token)
    execute_home_plan(plan)
    return {"kind": "home", "text": plan["spoken"], "executed": True}


def generate_gemini_tts(text: str, style: str | None = None) -> dict[str, Any]:
    if not gemini_ready():
        raise HTTPException(status_code=503, detail="GEMINI_API_KEY não configurada para voz natural.")
    clean = re.sub(r"https?://\S+", "", text).strip()[:6000]
    if not clean:
        raise HTTPException(status_code=400, detail="Texto vazio para síntese de voz.")
    style = (style or "Português brasileiro natural, humano, calmo e confiante; conversa próxima; ritmo variado; sem cadência robótica ou de locutor.")[:600]
    endpoint = "https://generativelanguage.googleapis.com/v1beta/interactions"
    payload = {
        "model": GEMINI_TTS_MODEL,
        "input": [{"type": "user_input", "content": [{
            "type": "text", "text": clean,
            "annotations": [{"type": "speech_metadata", "style": style}],
        }]}],
        "response_format": {"type": "audio", "mime_type": "audio/wav", "sample_rate": 24000},
        "generation_config": {"speech_config": [{"voice": GEMINI_TTS_VOICE}]},
    }
    req = urlrequest.Request(endpoint, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"), headers={
        "Content-Type": "application/json", "x-goog-api-key": os.environ["GEMINI_API_KEY"]
    }, method="POST")
    try:
        with urlrequest.urlopen(req, timeout=70) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urlerror.HTTPError as exc:
        detail = _gemini_error_detail(exc.read().decode("utf-8", errors="replace"))
        raise HTTPException(status_code=502, detail=f"Gemini TTS: {detail[:900]}") from exc
    except Exception as exc:
        raise HTTPException(status_code=504, detail=f"Falha temporária na voz natural: {exc}") from exc
    interaction = data.get("interaction") or {}
    audio = interaction.get("output_audio") or interaction.get("outputAudio") or {}
    b64 = audio.get("data") if isinstance(audio, dict) else None
    if not b64:
        raise HTTPException(status_code=502, detail="Gemini TTS respondeu sem áudio utilizável.")
    return {"b64_audio": b64, "mime_type": audio.get("mime_type") or audio.get("mimeType") or "audio/wav", "model": GEMINI_TTS_MODEL, "voice": GEMINI_TTS_VOICE}


def create_live_ephemeral_token() -> dict[str, Any]:
    if not gemini_ready():
        raise HTTPException(status_code=503, detail="GEMINI_API_KEY não configurada para ORUS Live.")
    endpoint = "https://generativelanguage.googleapis.com/v1beta/auth_tokens"
    payload = {
        "uses": 1,
        "liveConnectConstraints": {
            "model": f"models/{GEMINI_LIVE_MODEL}",
            "config": {"sessionResumption": {}, "responseModalities": ["AUDIO"]},
        },
    }
    req = urlrequest.Request(endpoint, data=json.dumps(payload).encode("utf-8"), headers={
        "Content-Type": "application/json", "x-goog-api-key": os.environ["GEMINI_API_KEY"]
    }, method="POST")
    try:
        with urlrequest.urlopen(req, timeout=25) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urlerror.HTTPError as exc:
        detail = _gemini_error_detail(exc.read().decode("utf-8", errors="replace"))
        raise HTTPException(status_code=502, detail=f"Gemini Live: {detail[:900]}") from exc
    token = data.get("name")
    if not token:
        raise HTTPException(status_code=502, detail="Gemini Live não retornou token temporário.")
    return {"token": token, "model": GEMINI_LIVE_MODEL, "voice": GEMINI_TTS_VOICE, "expires_in_hint": 1800}


@app.post("/v1/voice/speak", dependencies=[Depends(require_access)])
def voice_speak(req: VoiceSpeakRequest):
    return generate_gemini_tts(req.text, req.style)


@app.post("/v1/voice/live-token", dependencies=[Depends(require_access)])
def voice_live_token():
    return create_live_ephemeral_token()


@app.post("/v1/voice/command", dependencies=[Depends(require_access)])
def voice_command(req: VoiceCommandRequest):
    project_id = safe_project_id(req.project_id)
    if home_assistant_ready():
        try:
            home = handle_home_text(req.text)
            if home:
                return home
        except HTTPException as exc:
            if exc.status_code not in {400}:
                raise
    skill = route_skill(req.text)
    text = call_openai_text(req.text, "chat", project_id, skill)
    return {"kind": "chat", "text": text, "model": active_ai_model(), "skill": skill}


@app.post("/v1/chat", dependencies=[Depends(require_access)])
def chat(req: ChatRequest):
    project_id = safe_project_id(req.project_id)
    mode = (req.mode or "chat").lower().strip()
    if mode == "build":
        if not e2b_ready():
            raise HTTPException(status_code=503, detail="Executor E2B ainda não está configurado.")
        result = run_codex_build(req.message, project_id)
        stdout = result["stdout"].strip()
        stderr = result["stderr"].strip()
        text = stdout or "Execução concluída no E2B."
        if stderr:
            text += f"\n\nAvisos do executor:\n{stderr[:4000]}"
        return {"text": text, "executor": "e2b", "sandbox_id": result["sandbox_id"], "files": result["files"]}

    skill = route_skill(req.message, req.skill_id)
    skill_mode = str((skill or {}).get("mode") or "")
    if skill_mode == "home":
        if not home_assistant_ready():
            raise HTTPException(status_code=503, detail="Home Assistant ainda não está configurado no ORUS Core.")
        result = handle_home_text(req.message)
        if not result:
            raise HTTPException(status_code=400, detail="Não identifiquei um comando residencial claro.")
        result["skill"] = skill
        return result
    if skill_mode == "image":
        image = generate_image_payload(req.message)
        return {"kind": "image", "skill": skill, **image}
    if skill_mode == "voice":
        text = call_openai_text(req.message, "chat", project_id, skill, req.history)
        return {"kind": "voice", "text": text, "model": active_ai_model(), "skill": skill}

    effective_mode = mode
    if mode in {"chat", "omni"} and skill_mode in {"research", "code", "files"}:
        effective_mode = skill_mode
    text = call_openai_text(req.message, effective_mode, project_id, skill, req.history)
    return {"text": text, "model": active_ai_model(), "mode": effective_mode, "skill": skill, "omni": _omni_features(req.message, effective_mode)}


@app.post("/v1/agents/run", dependencies=[Depends(require_access)])
def run_agent(req: AgentRunRequest):
    project_id = safe_project_id(req.project_id)
    agent_prompts = {
        "Product": "Converta a missão em requisitos, escopo e critérios de aceite.",
        "Research": "Identifique informações necessárias, riscos de suposições e fontes a consultar.",
        "Architect": "Defina arquitetura, componentes, integrações e decisões técnicas.",
        "Designer": "Defina experiência, fluxos, hierarquia visual e estados da interface.",
        "Frontend": "Defina implementação da interface, componentes, responsividade e acessibilidade.",
        "Backend": "Defina APIs, dados, autenticação, integrações e observabilidade.",
        "Mobile": "Defina comportamento mobile, Android, performance e permissões.",
        "Data": "Defina dados, métricas, consultas e validações.",
        "Tester": "Crie um plano de testes funcional, integração e regressão.",
        "Debugger": "Procure falhas prováveis, causas-raiz e correções.",
        "Security": "Revise segredos, permissões, autenticação, abuso e proteção de dados.",
        "Reviewer": "Faça revisão final, inconsistências e checklist de entrega.",
    }
    instruction = agent_prompts.get(req.agent, "Analise a missão de acordo com sua especialidade.")
    prompt = f"Você é o agente {req.agent} da ORUS. {instruction}\n\nMISSÃO:\n{req.mission}\n\nResponda de forma curta, prática e acionável."
    summary = call_openai_text(prompt, "chat", project_id)
    return {"agent": req.agent, "summary": summary}


@app.post("/v1/files", dependencies=[Depends(require_access)])
async def upload_file(file: UploadFile = File(...), project_id: str = Form(default="general")):
    data = await file.read()
    if len(data) > 20 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Arquivo maior que 20 MB.")
    project_id = safe_project_id(project_id)
    safe_name = safe_upload_name(file.filename)
    project_dir = (UPLOAD_DIR / project_id).resolve()
    upload_root = UPLOAD_DIR.resolve()
    if project_dir.parent != upload_root:
        raise HTTPException(status_code=400, detail="project_id inválido.")
    project_dir.mkdir(parents=True, exist_ok=True)
    dest = project_dir / safe_name
    dest.write_bytes(data)
    text = extract_upload_text(safe_name, data)
    vision = False
    if not text and (file.content_type or "").startswith("image/"):
        text = describe_uploaded_image(safe_name, data, file.content_type)
        vision = bool(text)
    if text:
        PROJECT_TEXT_INDEX.setdefault(project_id, []).append({"name": safe_name, "text": text})
    return {"name": safe_name, "size": len(data), "indexed": bool(text), "vision": vision}


@app.post("/v1/images", dependencies=[Depends(require_access)])
def generate_image(req: ImageRequest):
    safe_project_id(req.project_id)
    return generate_image_payload(req.prompt)


@app.post("/v1/execute", dependencies=[Depends(require_access)])
def execute(req: ExecuteRequest):
    project_id = safe_project_id(req.project_id)
    sbx = connect_or_create_sandbox(project_id)
    try:
        result = sbx.commands.run(req.command, cwd="/tmp/orus", timeout=req.timeout, request_timeout=req.timeout + 10)
        return {
            "sandbox_id": sbx.sandbox_id,
            "stdout": getattr(result, "stdout", "") or "",
            "stderr": getattr(result, "stderr", "") or "",
        }
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Falha no executor: {exc}") from exc


@app.get("/v1/evolution/status", dependencies=[Depends(require_access)])
def evolution_status():
    state = evolution_state()
    requests = max(1, int(RUNTIME_METRICS.get("requests", 0)))
    avg = float(RUNTIME_METRICS.get("total_latency_ms", 0.0)) / requests
    candidates = []
    for path in sorted((EVOLUTION_DIR / "candidates").glob("*/candidate.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:20]:
        meta = _json_read(path, {})
        if meta:
            candidates.append(meta)
    checkpoints = []
    for path in sorted((EVOLUTION_DIR / "checkpoints").glob("*/checkpoint.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:20]:
        meta = _json_read(path, {})
        if meta:
            checkpoints.append(meta)
    return {
        "version": APP_VERSION,
        "enabled": True,
        "source_manifest": source_manifest(),
        "metrics": {"requests": RUNTIME_METRICS.get("requests", 0), "errors": RUNTIME_METRICS.get("errors", 0), "avg_latency_ms": round(avg, 1), "recent_errors": RUNTIME_METRICS.get("recent_errors", [])[-10:]},
        "candidates": candidates,
        "checkpoints": checkpoints,
        "approved_candidate": state.get("approved_candidate"),
        "rollback_target": state.get("rollback_target"),
        "feedback_count": len(state.get("feedback", [])),
    }


@app.post("/v1/evolution/feedback", dependencies=[Depends(require_access)])
def evolution_feedback(req: EvolutionFeedbackRequest):
    state = evolution_state()
    rows = state.setdefault("feedback", [])
    rows.append({"time": int(time.time()), "kind": req.kind[:40], "text": req.text[:8000]})
    state["feedback"] = rows[-200:]
    save_evolution_state(state)
    return {"ok": True, "feedback_count": len(state["feedback"])}


@app.post("/v1/evolution/analyze", dependencies=[Depends(require_access)])
def evolution_analyze(req: EvolutionAnalyzeRequest):
    instructions = (
        "Você é o agente de autoaprimoramento da ORUS. Faça uma auditoria técnica da própria ORUS usando o digest de código, métricas e feedback. "
        "Priorize segurança, confiabilidade, compatibilidade, velocidade, UX mobile e testes. Não proponha remover autenticação, gates de confirmação ou proteções. "
        "Raciocine como um conselho técnico com quatro papéis: Arquiteto, Security Reviewer, Mobile/Performance Reviewer e Tester. "
        "Separe: achados críticos, melhorias de alto valor, riscos, regressões possíveis e plano verificável. Não afirme que uma mudança foi aplicada."
    )
    text = call_gemini_text(
        f"OBJETIVO:\n{req.goal}\n\nESTADO ATUAL:\n{source_digest_for_ai()}",
        instructions,
    ) if active_ai_provider() == "gemini" else call_openai_text(
        f"OBJETIVO:\n{req.goal}\n\nESTADO ATUAL:\n{source_digest_for_ai()}",
        "code",
        "orus_self_evolution",
    )
    if not text:
        raise HTTPException(status_code=502, detail="A análise de evolução retornou vazia.")
    return {"analysis": text, "manifest": source_manifest(), "skills_count": len(SKILLS), "provider": active_ai_provider(), "model": active_ai_model()}


@app.post("/v1/evolution/create", dependencies=[Depends(require_access)])
def evolution_create(req: EvolutionCreateRequest):
    if not e2b_ready():
        raise HTTPException(status_code=503, detail="E2B_API_KEY é necessária para gerar uma candidata em sandbox.")
    if not ai_ready():
        raise HTTPException(status_code=503, detail="Configure GEMINI_API_KEY ou OPENAI_API_KEY para autoaprimoramento.")
    candidate_id = make_evolution_id("cand")
    local_dir = candidate_dir(candidate_id)
    snapshot_current(local_dir)
    sbx = connect_or_create_sandbox("orus_self_evolution")
    remote = f"/tmp/orus/{candidate_id}"
    try:
        sbx.commands.run(f"mkdir -p {shlex.quote(remote + '/client')}", timeout=20, request_timeout=25)
        for name, src in self_source_files().items():
            content = src.read_text(encoding="utf-8", errors="replace")
            sbx.files.write(f"{remote}/{name}", content)
        planning = call_gemini_text(
            "Produza um plano curto, técnico e verificável para evoluir esta aplicação sem regressão. "
            "Inclua riscos de segurança, desempenho mobile, testes e rollback. OBJETIVO: " + req.goal,
            "Você é o arquiteto-chefe da ORUS. Não aplique mudanças; planeje para outro agente executar dentro de sandbox."
        ) if gemini_ready() else "Planejar, implementar mudanças mínimas, testar e revisar regressões."
        prompt = (
            "Você é o engenheiro de autoaprimoramento da ORUS. Trabalhe SOMENTE nesta cópia candidata. "
            "Implemente o objetivo com mudanças pequenas, reversíveis e verificáveis. Preserve todas as funcionalidades existentes, autenticação, confirmações de ações sensíveis e proteção de segredos. "
            "Não altere .env, não publique nada e não tente acessar sistemas fora do sandbox. Não embuta chaves no código. "
            "Faça uma revisão final de segurança, performance mobile, compatibilidade e regressão antes de encerrar. "
            "Depois rode testes de sintaxe e consistência.\n\nPLANO DO ARQUITETO:\n" + planning[:8000] + "\n\nOBJETIVO:\n" + req.goal
        )
        if gemini_ready():
            cmd = (
                "npx -y @google/gemini-cli --approval-mode yolo --skip-trust "
                + "-m " + shlex.quote(GEMINI_MODEL) + " -p " + shlex.quote(prompt)
            )
        else:
            cmd = "codex exec --skip-git-repo-check --dangerously-bypass-approvals-and-sandbox " + shlex.quote(prompt)
        result = sbx.commands.run(cmd, cwd=remote, timeout=240, request_timeout=250)
        known = list(self_source_files().keys())
        for name in known:
            try:
                content = sbx.files.read(f"{remote}/{name}", format="text")
                dst = local_dir / name
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_text(content, encoding="utf-8")
            except Exception:
                pass
        tests = validate_candidate_local(local_dir)
        diff = build_diff_summary(self_source_files(), local_dir)
        tests.append({"name": "changes_present", "ok": bool(diff["changed_files"]), "count": len(diff["changed_files"])})
        all_ok = all(t.get("ok") for t in tests)
        review = ""
        try:
            review = call_gemini_text(
                f"OBJETIVO: {req.goal}\n\nTESTES: {json.dumps(tests, ensure_ascii=False)}\n\nDIFF RESUMIDO:\n{diff['diff_preview'][:16000]}",
                "Você é o revisor final da ORUS. Aponte apenas riscos reais, possíveis regressões, falhas de segurança e melhorias de teste. Seja conciso. Não aprove automaticamente."
            ) if gemini_ready() else ""
        except Exception:
            review = "Revisão de IA indisponível; os testes determinísticos continuam válidos."
        meta = {
            "candidate_id": candidate_id,
            "base_version": APP_VERSION,
            "created_at": int(time.time()),
            "goal": req.goal,
            "status": "tested" if all_ok else "failed_tests",
            "tests": tests,
            "changed_files": diff["changed_files"],
            "diff_preview": diff["diff_preview"],
            "ai_review": review[:12000],
            "quality_gate": "pass" if all_ok else "fail",
            "sandbox_id": sbx.sandbox_id,
            "executor_stdout": (getattr(result, "stdout", "") or "")[-8000:],
            "executor_stderr": (getattr(result, "stderr", "") or "")[-4000:],
        }
        write_candidate_meta(local_dir, meta)
        return meta
    except HTTPException:
        raise
    except Exception as exc:
        meta = {"candidate_id": candidate_id, "base_version": APP_VERSION, "created_at": int(time.time()), "goal": req.goal, "status": "generation_error", "error": str(exc)[:1200]}
        write_candidate_meta(local_dir, meta)
        raise HTTPException(status_code=502, detail=f"Falha ao gerar candidata: {exc}") from exc


@app.get("/v1/evolution/candidates/{candidate_id}", dependencies=[Depends(require_access)])
def evolution_candidate(candidate_id: str):
    path = candidate_dir(candidate_id)
    meta = candidate_meta(path)
    if not meta:
        raise HTTPException(status_code=404, detail="Candidata não encontrada.")
    return meta


@app.post("/v1/evolution/approve", dependencies=[Depends(require_access)])
def evolution_approve(req: EvolutionApproveRequest):
    if not req.confirm:
        raise HTTPException(status_code=400, detail="Confirmação explícita necessária para aprovar uma candidata.")
    path = candidate_dir(req.candidate_id)
    meta = candidate_meta(path)
    if not meta:
        raise HTTPException(status_code=404, detail="Candidata não encontrada.")
    if meta.get("status") not in {"tested", "approved"} or not all(t.get("ok") for t in meta.get("tests", [])):
        raise HTTPException(status_code=409, detail="A candidata precisa passar em todos os testes antes da aprovação.")
    checkpoint_id = make_evolution_id("cp")
    cp = checkpoint_dir(checkpoint_id)
    snapshot_current(cp)
    cp_meta = {"checkpoint_id": checkpoint_id, "version": APP_VERSION, "created_at": int(time.time()), "reason": f"Antes de aprovar {req.candidate_id}"}
    _json_write(cp / "checkpoint.json", cp_meta)
    approved_dir = EVOLUTION_DIR / "approved" / req.candidate_id
    if approved_dir.exists():
        shutil.rmtree(approved_dir)
    shutil.copytree(path, approved_dir)
    zip_path = package_directory(approved_dir, EVOLUTION_DIR / "approved" / f"{req.candidate_id}.zip")
    meta["status"] = "approved"
    meta["approved_at"] = int(time.time())
    meta["checkpoint_id"] = checkpoint_id
    meta["package"] = zip_path.name
    write_candidate_meta(path, meta)
    state = evolution_state()
    state["approved_candidate"] = req.candidate_id
    state["rollback_target"] = None
    save_evolution_state(state)
    return {"approved": True, "candidate_id": req.candidate_id, "checkpoint_id": checkpoint_id, "package": zip_path.name, "note": "Aprovada para implantação. O processo em execução não foi substituído automaticamente."}


@app.post("/v1/evolution/rollback", dependencies=[Depends(require_access)])
def evolution_rollback(req: EvolutionRollbackRequest):
    if not req.confirm:
        raise HTTPException(status_code=400, detail="Confirmação explícita necessária para preparar rollback.")
    cp = checkpoint_dir(req.checkpoint_id)
    meta_path = cp / "checkpoint.json"
    if not meta_path.exists():
        raise HTTPException(status_code=404, detail="Checkpoint não encontrado.")
    zip_path = package_directory(cp, EVOLUTION_DIR / "approved" / f"rollback_{req.checkpoint_id}.zip")
    state = evolution_state()
    state["rollback_target"] = req.checkpoint_id
    save_evolution_state(state)
    return {"prepared": True, "checkpoint_id": req.checkpoint_id, "package": zip_path.name, "note": "Rollback preparado; não foi aplicado silenciosamente ao processo em execução."}


@app.get("/v1/sandbox/files", dependencies=[Depends(require_access)])
def sandbox_files(project_id: str = "general"):
    project_id = safe_project_id(project_id)
    sbx = connect_or_create_sandbox(project_id)
    try:
        entries = sbx.files.list("/tmp/orus", depth=3)
        return {
            "sandbox_id": sbx.sandbox_id,
            "files": [
                {
                    "name": getattr(e, "name", None),
                    "path": getattr(e, "path", None),
                    "type": str(getattr(e, "type", "")),
                }
                for e in entries[:300]
            ],
        }
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Falha ao listar arquivos do sandbox: {exc}") from exc


@app.get("/v1/sandbox/file", dependencies=[Depends(require_access)])
def sandbox_file(path: str, project_id: str = "general"):
    project_id = safe_project_id(project_id)
    path = safe_sandbox_path(path)
    sbx = connect_or_create_sandbox(project_id)
    try:
        content = sbx.files.read(path, format="text")
        return {"path": path, "content": content[:500000]}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Falha ao ler arquivo do sandbox: {exc}") from exc


@app.get("/v1/diagnostics", dependencies=[Depends(require_access)])
def diagnostics():
    required = ["route_skill","build_instructions","project_context","connect_or_create_sandbox","run_codex_build","generate_gemini_svg_payload"]
    missing = [name for name in required if not callable(globals().get(name))]
    return {
        "version": APP_VERSION, "ok": not missing, "missing_callables": missing,
        "cors_origins": ALLOWED_ORIGINS,
        "e2b_secret_isolation": os.getenv("ORUS_E2B_AI_CLI", "0").strip().lower() not in {"1","true","yes"},
        "evolution_storage": str(EVOLUTION_DIR),
        "warning": "Em Vercel serverless, /tmp e memória podem desaparecer entre invocações; use armazenamento persistente externo para histórico durável." if str(EVOLUTION_DIR).startswith("/tmp/") else None,
    }


# Frontend ORUS: mounted last so API routes keep priority.
app.mount("/", StaticFiles(directory=str(Path(__file__).with_name("static")), html=True), name="orus_frontend")
