ORUS V53.5 — correção E2B

Correção principal:
- O workspace do E2B deixou de usar /home/oai/share, que retornava Permission denied.
- Agora usa /tmp/orus, criado automaticamente e gravável no sandbox.
- Corrigidos: execução, geração de candidata, leitura de arquivos e listagem do sandbox.

Variáveis Vercel:
- GEMINI_API_KEY
- E2B_API_KEY
- ORUS_ACCESS_TOKEN
Opcionais:
- OPENAI_API_KEY
- GEMINI_MODEL=gemini-3.5-flash-lite
- ORUS_AI_PROVIDER=auto
