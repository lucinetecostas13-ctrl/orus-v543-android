ORUS V53.4 — modo gratuito Gemini + E2B

Variáveis Vercel (Production / Secret):
- GEMINI_API_KEY  (necessária para IA gratuita)
- E2B_API_KEY     (executor/sandbox)
- ORUS_ACCESS_TOKEN (proteção do Core)

Opcionais:
- OPENAI_API_KEY (fallback/imagens quando houver créditos)
- GEMINI_MODEL=gemini-3.5-flash-lite
- ORUS_AI_PROVIDER=auto

Com GEMINI_API_KEY configurada, o modo auto prefere Gemini.
O autoaprimoramento usa Gemini CLI dentro do E2B quando Gemini estiver configurado.
