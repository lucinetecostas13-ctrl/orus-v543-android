ORUS V54.3 — revisão técnica corretiva

Correções principais:
- Restauradas funções críticas perdidas na V54.2: roteamento de habilidades, instruções, contexto de arquivos, E2B build e SVG.
- Corrigido fallback Gemini que podia recursar indefinidamente quando ferramentas retornavam 400/403.
- Home Assistant passa a usar o provedor ativo (Gemini ou OpenAI), não somente OpenAI.
- Confirmações sensíveis residenciais usam token HMAC assinado, funcionando melhor em serverless.
- CORS fechado por padrão; libere origens explicitamente com ORUS_ALLOWED_ORIGINS se frontend e Core estiverem em domínios diferentes.
- CSP e cabeçalhos de segurança reforçados.
- Chaves de IA não entram no E2B por padrão. O modo antigo pode ser reativado explicitamente com ORUS_E2B_AI_CLI=1.
- Build E2B padrão passa a receber um script gerado pelo Core, mantendo segredos fora do sandbox.
- Android WebView restringe navegação/permissão de microfone ao host confiável do Core.
- Voz Android em segundo plano tenta Gemini TTS neural; Android TTS vira fallback.
- Workflow GitHub Actions incluído para gerar APK debug sem computador local.

Limitação conhecida:
- Vercel serverless não oferece persistência durável em /tmp ou memória. Histórico de evolução, uploads e IDs de sandbox podem sumir em cold starts/redeploys. Para produção, use armazenamento externo persistente.
- O reconhecimento contínuo de palavra de ativação no Android depende do SpeechRecognizer do aparelho e de um foreground service; não equivale ao hotword privilegiado do assistente de sistema.
