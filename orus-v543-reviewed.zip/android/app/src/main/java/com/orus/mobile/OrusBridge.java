package com.orus.mobile;

import android.content.Intent;
import android.os.Build;
import android.webkit.JavascriptInterface;

public class OrusBridge {
    private final MainActivity activity;
    OrusBridge(MainActivity activity){this.activity=activity;}
    @JavascriptInterface public boolean isAvailable(){return true;}
    @JavascriptInterface public boolean isWakeActive(){return VoiceWakeService.running;}
    @JavascriptInterface public void configureCore(String url,String token){SecureStore.saveCore(activity,url,token);}
    @JavascriptInterface public void startWakeWord(){activity.runOnUiThread(() -> activity.startWakeService());}
    @JavascriptInterface public void stopWakeWord(){activity.runOnUiThread(() -> activity.stopWakeService());}
}