package com.orus.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.webkit.*;
import org.json.JSONObject;
import java.net.URL;

public class MainActivity extends Activity {
    public static final String ACTION_WAKE_COMMAND="com.orus.mobile.WAKE_COMMAND";
    public static final String ACTION_WAKE_STATE="com.orus.mobile.WAKE_STATE";
    private WebView webView;
    private final BroadcastReceiver receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){
        if(ACTION_WAKE_COMMAND.equals(i.getAction())) deliver(i.getStringExtra("text"));
        if(ACTION_WAKE_STATE.equals(i.getAction())) wakeState(i.getBooleanExtra("active",false),i.getStringExtra("message"));
    }};

    private boolean trusted(String raw){
        try{
            URL want=new URL(SecureStore.coreUrl(this)); URL got=new URL(raw);
            return "https".equalsIgnoreCase(got.getProtocol()) && want.getHost().equalsIgnoreCase(got.getHost());
        }catch(Exception e){return false;}
    }

    @Override public void onCreate(Bundle b){super.onCreate(b);
        webView=new WebView(this);setContentView(webView);
        WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if(Build.VERSION.SDK_INT>=26)s.setSafeBrowsingEnabled(true);
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){String u=r.getUrl().toString();if(trusted(u))return false;try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception ignored){}return true;}
            @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap icon){if(!trusted(url)){v.stopLoading();}}
        });
        webView.setWebChromeClient(new WebChromeClient(){@Override public void onPermissionRequest(PermissionRequest r){runOnUiThread(()->{
            if(!trusted(r.getOrigin().toString())){r.deny();return;}
            for(String x:r.getResources())if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x)){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)r.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});else requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},101);return;}r.deny();});}});
        webView.addJavascriptInterface(new OrusBridge(this),"OrusNative");
        IntentFilter filter=new IntentFilter();filter.addAction(ACTION_WAKE_COMMAND);filter.addAction(ACTION_WAKE_STATE);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,filter,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,filter);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},102);
        String url=SecureStore.coreUrl(this);if(trusted(url))webView.loadUrl(url);
    }
    public void startWakeService(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},101);return;}Intent i=new Intent(this,VoiceWakeService.class).setAction("START");if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}
    public void stopWakeService(){startService(new Intent(this,VoiceWakeService.class).setAction("STOP"));}
    private void deliver(String text){if(text==null||text.trim().isEmpty())return;String js="window.__ORUS_NATIVE_COMMAND&&window.__ORUS_NATIVE_COMMAND("+JSONObject.quote(text.trim())+");";webView.post(()->webView.evaluateJavascript(js,null));}
    private void wakeState(boolean active,String message){String js="window.__ORUS_NATIVE_WAKE_STATE&&window.__ORUS_NATIVE_WAKE_STATE("+(active?"true":"false")+","+JSONObject.quote(message==null?"":message)+");";webView.post(()->webView.evaluateJavascript(js,null));}
    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception ignored){}if(webView!=null){webView.removeJavascriptInterface("OrusNative");webView.destroy();}super.onDestroy();}
}
