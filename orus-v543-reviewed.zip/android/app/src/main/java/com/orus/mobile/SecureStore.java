package com.orus.mobile;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.net.URL;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public final class SecureStore {
    private static final String ALIAS = "ORUS_CORE_TOKEN_V1";
    private static final String PREF = "orus_native_secure";
    private SecureStore() {}

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            kg.generateKey();
        }
        return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
    }
    public static void saveCore(Context c, String url, String token) {
        try {
            String clean=url==null?"":url.trim(); URL parsed=new URL(clean);
            if(!"https".equalsIgnoreCase(parsed.getProtocol())) return;
            SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
            SharedPreferences.Editor e=p.edit().putString("core_url",clean);
            if(token==null||token.isEmpty()){e.remove("token_ct").remove("token_iv").apply();return;}
            Cipher cp=Cipher.getInstance("AES/GCM/NoPadding");cp.init(Cipher.ENCRYPT_MODE,key());
            byte[] ct=cp.doFinal(token.getBytes(StandardCharsets.UTF_8));
            e.putString("token_ct",Base64.encodeToString(ct,Base64.NO_WRAP));
            e.putString("token_iv",Base64.encodeToString(cp.getIV(),Base64.NO_WRAP));e.apply();
        } catch(Exception ignored) {}
    }
    public static String coreUrl(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("core_url","https://orus-v543.vercel.app");}
    public static String token(Context c){
        try{
            SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);String ct=p.getString("token_ct",null),iv=p.getString("token_iv",null);if(ct==null||iv==null)return "";
            Cipher cp=Cipher.getInstance("AES/GCM/NoPadding");cp.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));
            return new String(cp.doFinal(Base64.decode(ct,Base64.NO_WRAP)),StandardCharsets.UTF_8);
        }catch(Exception e){return "";}
    }
}