ORUS V54.0 — Neural Command Interface

Principais melhorias:
- Gemini 3.8 Flash como cérebro principal, com fallback automático entre modelos e retry para alta demanda.
- Pesquisa Gemini com Google Search grounding quando disponível.
- Voz natural Gemini 3.8 Flash TTS, voz Orus, com fallback para voz do aparelho.
- ORUS Live com Gemini 3.8 Live via token efêmero: chave Gemini permanece no servidor.
- Interface HUD futurista, mobile-first, sem copiar ativos proprietários.
- Imagem Gemini 3.1 Flash Image opcional para contas com faturamento; SVG seguro permanece como fallback gratuito.
- Autoaprimoramento corrigido para incluir app.py e toda a estrutura Vercel.
- Evolução em duas fases: plano de arquiteto + implementação E2B + testes determinísticos + revisão final da IA.
- Novos testes contra regressões, remoção de APIs, /home/oai e segredos embutidos.
- Cabeçalhos adicionais de segurança e preservação das confirmações de ações sensíveis.

Variáveis existentes continuam válidas:
GEMINI_API_KEY
E2B_API_KEY
ORUS_ACCESS_TOKEN

Opcionais:
GEMINI_MODEL=gemini-3.8-flash
GEMINI_TTS_MODEL=gemini-3.8-flash-tts
GEMINI_TTS_VOICE=Orus
GEMINI_LIVE_MODEL=gemini-3.8-live
GEMINI_IMAGE_MODEL=gemini-3.1-flash-image
ORUS_NATIVE_IMAGE=1 (exige disponibilidade/faturamento do modelo de imagem)
