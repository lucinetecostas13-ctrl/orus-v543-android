ORUS V53.7 — correção de timeout na geração de imagem

Mudanças:
- Pedidos de imagem podem aguardar até 120 segundos no celular.
- Gemini SVG é priorizado quando disponível, evitando tentativas desnecessárias na OpenAI sem créditos.
- Geração SVG usa saída menor e mais eficiente para reduzir latência.
- Mensagens de timeout de imagem ficaram mais claras.
- Mantém todos os ajustes da V53.6 e a correção E2B em /tmp/orus.

Variáveis:
- GEMINI_API_KEY
- E2B_API_KEY
- ORUS_ACCESS_TOKEN
Opcional:
- ORUS_IMAGE_PROVIDER=gemini
