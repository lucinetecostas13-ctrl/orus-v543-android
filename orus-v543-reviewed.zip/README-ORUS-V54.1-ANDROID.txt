ORUS V54.1 — Android Native Voice Layer

O pacote contém o ORUS Core/Web completo e um projeto Android nativo em /android.

O que foi adicionado:
- Serviço Android de primeiro plano para palavra de ativação “Orus”.
- Escuta pode continuar com tela apagada enquanto o Android/OEM permitir o microfone.
- Notificação permanente deixa claro quando o microfone está ativo e permite parar.
- Comandos após “Orus” podem ser enviados diretamente ao /v1/voice/command, inclusive com a tela apagada.
- ORUS_ACCESS_TOKEN é guardado criptografado pelo Android Keystore, não embutido no APK.
- Integração WebView ↔ Android: a tela Sistema sincroniza Core URL + token com o cofre nativo.
- Mantém ORUS Live, voz neural Gemini, 250 habilidades, E2B e autoaprimoramento.

Fluxo recomendado:
1) Publique este ZIP no Vercel com nome orus-v541 e configure GEMINI_API_KEY, E2B_API_KEY e ORUS_ACCESS_TOKEN.
2) Abra /android no Android Studio ou AndroidIDE e gere o APK.
3) Instale o APK, abra ORUS, vá em Sistema e salve o URL do Core e o token uma vez.
4) Vá em Casa e toque “Ativar Orus” ou “Voz em 2º plano”. Autorize microfone/notificações.
5) Teste: “Orus, olá” e, com a tela apagada, “Orus, que horas são?” (o backend responderá conforme as habilidades disponíveis).

Limitação real do Android:
- Apps comuns não recebem acesso privilegiado ao hotword DSP do sistema como Google Assistant/Alexa. A V54.1 usa um serviço de primeiro plano com microfone e notificação persistente. Alguns fabricantes podem suspender o processo se a otimização de bateria estiver agressiva. Nesses aparelhos, permita atividade em segundo plano para ORUS.
