ORUS V54.3.1 — HOTFIX

Correções aplicadas:
- Android agora restaura Core URL e ORUS_ACCESS_TOKEN do Android Keystore após reiniciar o app.
- Evita o erro recorrente de token ausente causado por sessionStorage vazio após reabrir o APK.
- GITHUB_TOKEN agora é realmente lido pelo ORUS Core.
- Comandos de leitura como “conecte ao GitHub e liste os arquivos de owner/repo” usam a API oficial do GitHub no backend.
- Integração GitHub desta hotfix é somente leitura: não altera, cria nem exclui arquivos.
- Health passa a informar github_configured.
- Nenhum segredo é embutido no HTML ou no APK.

Configuração necessária no Vercel:
- ORUS_ACCESS_TOKEN: token privado escolhido pelo proprietário.
- GITHUB_TOKEN: fine-grained PAT com acesso somente aos repositórios necessários e permissões mínimas de leitura para Contents/Metadata.
- GEMINI_API_KEY e E2B_API_KEY conforme uso.

Importante:
- O APK é pequeno por projeto: ele é uma camada Android nativa/WebView e carrega a interface ORUS publicada no Core. O tamanho reduzido não significa, por si só, build incompleto.
- Para o navegador web, o ORUS_ACCESS_TOKEN continua apenas na sessão do navegador. No APK Android ele é persistido criptografado via Android Keystore.
