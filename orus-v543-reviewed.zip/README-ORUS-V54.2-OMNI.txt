ORUS V54.2 — Omni Neural Interface

Objetivo: aproximar os fluxos públicos do ChatGPT e das IAs modernas sem fingir acesso a sistemas internos proprietários.

Principais melhorias:
- Modo Omni: roteia automaticamente entre conversa, pesquisa atual, contexto de URL, execução de código e raciocínio profundo.
- Raciocínio profundo: thinking level HIGH no Gemini 3.8 Flash para tarefas complexas.
- Pesquisa web: Google Search grounding e fontes consultadas; OpenAI web_search quando configurada.
- Contexto de URL: lê páginas/URLs no Gemini quando presentes no pedido.
- Execução de código: ferramenta code_execution do Gemini; E2B continua disponível para builds e arquivos reais.
- Memória conversacional: últimas mensagens do projeto são enviadas ao Core a cada turno; persiste no navegador por projeto.
- Arquivos: TXT/MD/CSV/JSON/PDF/DOCX/PPTX/XLSX/RTF/código, além de descrição visual de imagens via Gemini.
- Voz: mantém TTS natural, ORUS Live e wake word Android da V54.1.
- Imagem: mantém imagem nativa opcional e SVG gratuito como fallback.
- Agentes, Home Assistant, E2B, 250 habilidades, checkpoints e rollback preservados.

Variáveis mínimas no Vercel:
- GEMINI_API_KEY
- E2B_API_KEY
- ORUS_ACCESS_TOKEN

Opcionais:
- OPENAI_API_KEY (habilita GPT-5.6 como provedor alternativo)
- ORUS_AI_PROVIDER=auto|gemini|openai
- ORUS_NATIVE_IMAGE=1 para imagem raster nativa quando a conta/tier suportar

Nota: funcionalidades internas privadas do ChatGPT, pesos do modelo, memória de conta e ferramentas proprietárias do produto não podem ser copiadas literalmente. A V54.2 reproduz fluxos equivalentes usando APIs públicas e ferramentas configuradas pelo usuário.
