ORUS V53.6 — identidade, Markdown, imagem e estabilidade do Core

Correções:
- ORUS não se apresenta mais como ChatGPT/Gemini por padrão.
- Instruções de capacidades reais do ORUS reforçadas.
- Markdown básico renderizado corretamente (**negrito**, títulos, código).
- Pedidos óbvios de criação de imagem são enviados para a habilidade de imagem.
- Modo gratuito de imagem: gera uma ilustração vetorial SVG via Gemini.
- Se houver provedor raster compatível, ele pode ser usado; se falhar, ORUS cai para SVG.
- Status do Core tolera falhas transitórias e só muda para offline após 3 falhas consecutivas.
- Mantém a correção E2B da V53.5 (/tmp/orus).

Variáveis recomendadas no Vercel:
- GEMINI_API_KEY
- E2B_API_KEY
- ORUS_ACCESS_TOKEN
Opcionais:
- OPENAI_API_KEY
- GEMINI_MODEL=gemini-3.5-flash-lite
- ORUS_AI_PROVIDER=auto
